# Tetris-Example-Cocos2dx
cocos2d-x windows / c++ 11/14 / design pattern

# Tetris-Example-Cocos2dx-cpp
# Visual Studio 2017 Community C++ 11/14
# cocos2d-x-3.14.1 
# Design pattern: 
.Observer .Factory .Mediator .Singleton

# playtest video youtube
[![Video Label](http://img.youtube.com/vi/mKlZ9tGgI7k/0.jpg)](https://www.youtube.com/watch?v=mKlZ9tGgI7k) 

# Blog (exe download) URL: http://affineur.tistory.com/13
